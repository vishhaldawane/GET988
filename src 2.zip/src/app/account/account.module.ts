import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SavingsAccountComponent } from './savings-account/savings-account.component';
import { CurrentAccountComponent } from './current-account/current-account.component';
import { FixedDepositComponent } from './fixed-deposit/fixed-deposit.component';



@NgModule({
  declarations: [
    SavingsAccountComponent,
    CurrentAccountComponent,
    FixedDepositComponent
  ],
  exports: [
    SavingsAccountComponent,
    FixedDepositComponent,
    CurrentAccountComponent
  ],
  imports: [
    CommonModule
  ]
})
export class AccountModule { }
