import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savings-account',
  templateUrl: './savings-account.component.html',
  styleUrls: ['./savings-account.component.css']
})
export class SavingsAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
