import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fixed-deposit',
  templateUrl: './fixed-deposit.component.html',
  styleUrls: ['./fixed-deposit.component.css']
})
export class FixedDepositComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
