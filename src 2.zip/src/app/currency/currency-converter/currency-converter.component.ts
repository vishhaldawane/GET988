import { Component, OnInit } from '@angular/core';
import { Currency } from '../Currency';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {

  theCurrency: Currency = new Currency();

  constructor(private ccs: CurrencyConverterService) { }

  sendForConversion() {
    this.ccs.convert(this.theCurrency);
  }
  
  ngOnInit(): void {
    this.theCurrency.sourceCurrency='USD';
    this.theCurrency.targetCurrency='INR';
    this.theCurrency.amount=5000;
  }
}
