import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    CurrencyConverterComponent
  ],
  exports : [
    CurrencyConverterComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class CurrencyModule { }
