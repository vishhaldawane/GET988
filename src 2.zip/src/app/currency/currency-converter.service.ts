import { Injectable } from '@angular/core';
import { Currency } from './Currency';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  constructor() { }
  
  convertedValue: number=0;

  convert(curr: Currency) {
    //alert('invoked for conversion...');
    console.log(curr);
    if(curr.sourceCurrency=='USD') {
      //alert('source is USD');
      if(curr.targetCurrency=='INR') {
        curr.conversionRate=76;
        this.convertedValue = curr.conversionRate * curr.amount;
        alert('Converted value '+this.convertedValue);
      }
    }
    else if(curr.sourceCurrency=='INR') {
      //alert('source is USD');
      if(curr.targetCurrency=='USD') {
        curr.conversionRate=76;
        this.convertedValue =   curr.amount /curr.conversionRate;
        alert('Converted value '+this.convertedValue);
      }
    }
    
  }
}
