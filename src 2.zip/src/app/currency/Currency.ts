export class Currency {
    sourceCurrency: string;
    targetCurrency: string;
    amount : number;
    conversionRate: number;

    constructor() {
        this.sourceCurrency='';
        this.targetCurrency='';
        this.amount=0;
        this.conversionRate=0;
    }
}