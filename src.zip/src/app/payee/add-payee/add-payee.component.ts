import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
