import { TestBed } from '@angular/core/testing';

import { BreakFastService } from './break-fast.service';

describe('BreakFastService', () => {
  let service: BreakFastService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BreakFastService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
