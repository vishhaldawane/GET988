import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
//java code like below 2 lines
//LunchService ls = new LunchService();
//ls.feelingHungryLetsHaveLunch();

export class LunchService {

  constructor() { }
  feelingHungryLetsHaveLunch() {
    alert('after this will take break for lunch..');
  }
}
