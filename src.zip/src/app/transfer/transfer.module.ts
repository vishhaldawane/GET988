import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';



@NgModule({
  declarations: [
    FundTransferComponent
  ],
  exports : [
    FundTransferComponent
  ],
  imports: [
    CommonModule
  ]
})
export class TransferModule { }
