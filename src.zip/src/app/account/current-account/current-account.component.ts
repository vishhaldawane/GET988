import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-account',
  templateUrl: './current-account.component.html',
  styleUrls: ['./current-account.component.css']
})
export class CurrentAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
