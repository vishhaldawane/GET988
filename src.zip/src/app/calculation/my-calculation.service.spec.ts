import { TestBed } from '@angular/core/testing';

import { MyCalculationService } from './my-calculation.service';

describe('MyCalculationService', () => {
  let service: MyCalculationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyCalculationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
