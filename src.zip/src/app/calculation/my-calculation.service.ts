import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyCalculationService {

  constructor() { }
  calculateCompoundInterest() {
    alert('calculateCompoundInterest');
  }
  calculateCurrencyRate() {
    alert('calculateCurrencyRate');
  }
  calculateSimpleInterest() {
    alert('calculateSimpleInterest');
  }
}
