import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReportCardComponent } from './report-card/report-card.component';
import { HeaderComponent } from './header/header.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { BankAccountComponent } from './bank-account/bank-account.component';
import { AccountModule } from './account/account.module';
import { PayeeModule } from './payee/payee.module';
import { TransferModule } from './transfer/transfer.module';
import { CalculationModule } from './calculation/calculation.module';
import { FoodModule } from './food/food.module';

@NgModule({
  declarations: [
    AppComponent,
    ReportCardComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    BankAccountComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    AccountModule,
    PayeeModule,
    TransferModule,
    CalculationModule,
    FoodModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
