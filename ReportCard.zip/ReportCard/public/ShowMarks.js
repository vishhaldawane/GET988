/**
 * 
 */

function calculateMarks() 
{
	
	//alert('Calculating Marks...');
	
	var physics = document.getElementById("phy").value;
	var chemistry = document.getElementById("chem").value;
	var maths = document.getElementById("math").value;
	var biology = document.getElementById("bio").value;
	var english = document.getElementById("eng").value;
	var geometry = document.getElementById("geom").value;
	
	var total = parseInt(physics)+parseInt(chemistry)+parseInt(maths)+parseInt(biology)+parseInt(english)+parseInt(geometry); // +maths+biology+english+geometry;
	
	//alert('physics marks '+physics+" chem "+chemistry+" maths "+maths+" bio "+biology+" eng "+english+" geom "+geometry+" total "+total);
	document.getElementById("total").value=total;
	
}